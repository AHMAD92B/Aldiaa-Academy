import '../globals.css';
import type { Metadata } from 'next';
import { ReactNode } from 'react';

export const metadata: Metadata = {
  title: 'أكاديمية الضياء',
  description: 'منصة تعليمية تفاعلية',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  // Determine direction based on language; default to RTL
  const dir = 'rtl';
  return (
    <html lang="ar" dir={dir}>
      <body className="min-h-screen bg-gray-50 text-gray-900">
        {children}
      </body>
    </html>
  );
}