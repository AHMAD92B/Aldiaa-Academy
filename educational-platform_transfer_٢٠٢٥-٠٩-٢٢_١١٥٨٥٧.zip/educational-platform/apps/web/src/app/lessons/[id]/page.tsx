'use client';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, QueryClient, QueryClientProvider } from '@tanstack/react-query';
import axios from 'axios';
import { useEffect, useState } from 'react';

interface Lesson {
  id: string;
  title: string;
  content?: string | null;
  videoUrl: string;
  quizzes: {
    id: string;
    question: string;
    options: string[];
    answer: number;
  }[];
}

interface Course {
  id: string;
  lessons: Lesson[];
}

const queryClient = new QueryClient();

export default function LessonPage() {
  return (
    <QueryClientProvider client={queryClient}>
      <LessonContent />
    </QueryClientProvider>
  );
}

function LessonContent() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [isOffline, setIsOffline] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [correct, setCorrect] = useState<boolean | null>(null);

  useEffect(() => {
    function handleOnline() {
      setIsOffline(!navigator.onLine);
    }
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOnline);
    setIsOffline(!navigator.onLine);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOnline);
    };
  }, []);

  const { data: courses, isLoading, error } = useQuery<Course[]>({
    queryKey: ['courses'],
    queryFn: async () => {
      const res = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/courses`);
      return res.data;
    },
  });

  const lesson: Lesson | undefined = courses
    ?.flatMap((course) => course.lessons)
    .find((l) => l.id === id);

  const mutation = useMutation({
    mutationFn: async (payload: { quizId: string; selected: number }) => {
      const userId = 'demo-user-id';
      const res = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/attempts`, {
        userId,
        quizId: payload.quizId,
        selected: payload.selected,
      });
      return res.data;
    },
    onSuccess: (data: { correct: boolean }) => {
      setCorrect(data.correct);
      setSubmitted(true);
    },
  });

  if (isLoading) {
    return <p className="p-4">يتم التحميل...</p>;
  }
  if (error || !lesson) {
    return <p className="p-4 text-red-600">لم يتم العثور على الدرس</p>;
  }

  const quiz = lesson.quizzes[0];

  const allLessons = courses?.flatMap((c) => c.lessons) || [];
  const currentIndex = allLessons.findIndex((l) => l.id === id);
  const nextLessonId = currentIndex >= 0 && currentIndex + 1 < allLessons.length ? allLessons[currentIndex + 1].id : undefined;

  return (
    <main className="p-4 space-y-4">
      {isOffline && (
        <div className="bg-yellow-100 text-yellow-800 p-2 rounded">
          أنت غير متصل بالإنترنت. سيتم عرض المحتوى المخزن مؤقتًا عند توفره.
        </div>
      )}
      <h1 className="text-2xl font-bold">{lesson.title}</h1>
      <video controls className="w-full max-h-[360px] bg-black" src={lesson.videoUrl} />
      {lesson.content && (
        <article className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: lesson.content }} />
      )}
      {quiz && (
        <section className="space-y-2">
          <h2 className="text-xl font-semibold">{quiz.question}</h2>
          <ul className="space-y-1">
            {quiz.options.map((opt: string, idx: number) => (
              <li key={idx} className="flex items-center">
                <input
                  type="radio"
                  name="option"
                  value={idx}
                  checked={selected === idx}
                  onChange={() => setSelected(idx)}
                  className="mr-2"
                />
                <span>{opt}</span>
              </li>
            ))}
          </ul>
          {!submitted ? (
            <button
              disabled={selected === null || mutation.isPending}
              onClick={() => {
                if (quiz && selected !== null) {
                  mutation.mutate({ quizId: quiz.id, selected });
                }
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
            >
              إرسال الإجابة
            </button>
          ) : (
            <p className={`font-bold ${correct ? 'text-green-600' : 'text-red-600'}`}>
              {correct ? 'إجابة صحيحة! أحسنت.' : 'إجابة خاطئة. حاول مرة أخرى.'}
            </p>
          )}
        </section>
      )}
      {submitted && nextLessonId && (
        <button
          onClick={() => router.push(`/lessons/${nextLessonId}`)}
          className="px-4 py-2 bg-green-600 text-white rounded"
        >
          الانتقال إلى الدرس التالي
        </button>
      )}
    </main>
  );
}